---
name: Vibrant Social Dining
colors:
  surface: '#f8f9ff'
  surface-dim: '#d1dbec'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eef4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dfe9fa'
  surface-container-highest: '#d9e3f4'
  on-surface: '#121c28'
  on-surface-variant: '#5b4041'
  inverse-surface: '#27313e'
  inverse-on-surface: '#eaf1ff'
  outline: '#8f6f71'
  outline-variant: '#e3bdbf'
  surface-tint: '#bc0b3b'
  primary: '#b90538'
  on-primary: '#ffffff'
  primary-container: '#dc2c4f'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb2b7'
  secondary: '#575e70'
  on-secondary: '#ffffff'
  secondary-container: '#d9dff5'
  on-secondary-container: '#5c6274'
  tertiary: '#006b2d'
  on-tertiary: '#ffffff'
  tertiary-container: '#00873b'
  on-tertiary-container: '#f7fff3'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdadb'
  primary-fixed-dim: '#ffb2b7'
  on-primary-fixed: '#40000d'
  on-primary-fixed-variant: '#92002a'
  secondary-fixed: '#dce2f7'
  secondary-fixed-dim: '#c0c6db'
  on-secondary-fixed: '#141b2b'
  on-secondary-fixed-variant: '#404758'
  tertiary-fixed: '#6bff8f'
  tertiary-fixed-dim: '#4ae176'
  on-tertiary-fixed: '#002109'
  on-tertiary-fixed-variant: '#005321'
  background: '#f8f9ff'
  on-background: '#121c28'
  surface-variant: '#d9e3f4'
  brand-surface: '#fff1f2'
  brand-accent: '#e11d48'
  surface-alt: '#f9fafb'
  border-subtle: '#f3f4f6'
  rating-gold: '#facc15'
typography:
  display-hero:
    fontFamily: Inter
    fontSize: 60px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '800'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-section:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-card:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '700'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-base:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.4'
  overline:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1.0'
    letterSpacing: 0.1em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-max: 1280px
  section-gap-lg: 6rem
  section-gap-sm: 4rem
  gutter: 1rem
  stack-md: 1rem
  stack-lg: 3rem
---

## Brand & Style

The design system is centered on a playful, energetic, and high-motion brand personality. It targets a young, social audience looking for frictionless experiences. The UI evokes a sense of appetite and urgency through its color palette, while maintaining a clean "App-First" web aesthetic.

The visual style is **Modern / Glassmorphic**, characterized by:
- **Depth and Layering:** Extensive use of background blobs, floating UI elements, and high-radius shadows.
- **Translucency:** Frosted glass navigation and subtle overlays to maintain context.
- **Friendly Geometry:** Soft, high-radius corners that feel approachable and non-threatening.
- **Interactive Motion:** Subtle floating animations and lifts that simulate a living, reactive application environment.

## Colors

The palette is dominated by the **Rose 500** primary color, chosen to stimulate appetite and energy. It is supported by a deep charcoal secondary color for high-contrast typography and a vibrant green for success states.

### Application Guidelines
- **Primary Rose:** Use for main CTAs, branding elements, and active indicators. Use the `30% opacity` version of this color for glowing shadows on primary buttons.
- **Brand Surface:** A very light rose tint used for badge backgrounds and soft alerts to maintain brand warmth without the intensity of the primary hex.
- **Neutrals:** Use `gray-50` for secondary section backgrounds and `gray-100` for subtle borders. Avoid pure black; use the secondary charcoal for headings to keep the look sophisticated yet readable.

## Typography

This design system relies exclusively on **Inter** to project a modern, tech-focused, and highly legible interface. The type hierarchy is intentionally bold, with significant weight contrast between headings and body text.

### Usage Notes
- **Hero Typography:** Use `display-hero` for primary value propositions. The tight letter spacing and heavy weight are essential for the "impact" aesthetic.
- **Readability:** Body text should utilize `body-lg` for introductory paragraphs to maintain a premium, airy feel.
- **Labels:** Use `overline` for category tags or step indicators, always in uppercase with increased letter spacing for distinct visual separation.

## Layout & Spacing

The layout follows a **Fluid Grid** model with a generous vertical rhythm. It mimics the breathing room found in premium mobile applications rather than dense data-heavy websites.

- **Grid:** A 12-column system for desktop, collapsing to 1 column for mobile.
- **Sectioning:** Major sections are separated by `section-gap-lg` (96px) to ensure focus on one feature at a time.
- **Horizontal Margins:** Use a standard 16px (`1rem`) margin on mobile, scaling to 32px on tablet, and centering within the 1280px container on desktop.
- **Component Layout:** Use `gap-12` (48px) for feature grids to prevent visual clutter between card elements.

## Elevation & Depth

Hierarchy is established through a combination of **Glassmorphism** and **Ambient Shadows**.

- **Glass Effect:** Applied to the primary navigation bar. Use a background of `rgba(255, 255, 255, 0.9)` with a `10px` backdrop blur. This ensures the colorful background blobs are visible while keeping text legible.
- **Shadows:** 
    - **Level 1 (Standard Cards):** Soft, wide-spread gray shadow with low opacity.
    - **Level 2 (Floating/Hero):** Extra-diffused `xl` shadow to simulate significant distance from the surface.
    - **Brand Glow:** Primary buttons use a colored shadow (`#f43f5e` at 30% opacity) to create a "vibrant" interactive feel.
- **Z-Index:** Background blobs must sit at `-10` to stay behind content, while floating UI elements like badges should sit at `10` or higher to clear card boundaries.

## Shapes

The shape language is defined by extreme roundedness, reinforcing the playful brand identity. 

- **Cards & Primary Blocks:** Use `rounded-3xl` (1.5rem / 24px) for major section containers and feature cards.
- **Inputs & Standard Buttons:** Use `rounded-xl` (0.75rem / 12px) for form elements and small interactive components.
- **Status & Badges:** Use `rounded-full` for all pill-shaped status indicators, tags, and circular social icons.
- **Mockups:** Mobile device frames should utilize a specific `2.5rem` radius to match modern hardware aesthetics.

## Components

### Buttons
- **Primary:** Background `primary_color_hex`, text white, `rounded-full`, with a `30% opacity` primary shadow. Lift 4px on hover.
- **Secondary:** Transparent background with a `1px` border of `gray-100`, text `gray-800`.

### Cards
- **Feature Cards:** `rounded-3xl`, white background, `1px` border of `border-subtle`, and a `shadow-lg`.
- **Interaction:** Cards should have a subtle `-translate-y-1` (4px lift) on hover with a smooth 300ms transition.

### Input Fields
- **Styling:** `rounded-xl`, `gray-50` background, `1px` border of `gray-100`. Focus state should use a `primary_color_hex` ring.

### Icons
- **Treatment:** Place icons inside "Soft Square" boxes (`rounded-xl`). Use `brand-surface` as the background with `primary_color_hex` for the icon itself to create a cohesive brand touchpoint.

### Glass Navbar
- **Styling:** Full width, sticky positioning, `glass-effect` background, and a bottom border of `border-subtle`.